// For todays date;
var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

Date.prototype.today = function () { 
    return ((this.getDate() < 10)?"0":"") 
      + this.getDate() + " "     
      + months[this.getMonth()] + " " 
      + this.getFullYear() + " - "
      + ((this.getHours() < 10)?"0":"") 
      + this.getHours() + ":" 
      + ((this.getMinutes() < 10)?"0":"") 
      + this.getMinutes()
    /*  +":"+ ((this.getSeconds() < 10)?"0":"") + this.getSeconds() */;
}

var NavBar = React.createClass({
  render: function() {
    var navList = ['About', 'Service', 'Blog', 'Contact'];
    var navLinks = navList.map(function(item) {
      return <li><a href='#'>{item}</a></li>;
    })

    return (
      <header>
        <div className='navbar'>
          <ul>
            {navLinks}
          </ul>          
        </div>
      </header>
    )
  }
});

var Home = React.createClass({
  render: function() {
    return (
      <section className='home clearfix'>
        <NavBar/>
        <div className="home-title">
          <h1>Your<br/> Blog</h1>
        </div>
        <button id='add-post'>ADD POST</button>       
      </section>
    )
  }
});

var SinglePost = React.createClass({  
  render: function() {
    return (
      <div className='post-container'>
        <div >
          <div className='post-image'><img src={this.props.postPhoto} className='post-photo'/></div>
            <div className='post-content'>
      	      <h2 className='post-title'>{this.props.postTitle}</h2>
       	      <p className='post-text'>{this.props.postText}</p>
            </div>
          </div>
        <hr/>
        <div className='post-info'>
          <div className='tags-container'>
            {this.props.postTags.map(function(data) {
             return <p>{data}</p>
            })}                        
          </div>
          <p className='post-author'>Written by: <span style={{fontStyle: 'italic', textDecoration: 'underline'}}>{this.props.postAuthor}</span></p>
          <p className='date'>{this.props.time}</p>
        </div>
      </div>
    )
  }
});

var Posts = React.createClass({  
  getInitialState: function() {
    return {
      post_photo: 'http://i1040.photobucket.com/albums/b406/purpleswag/your-blog-logo-280x224_zpsdcutthrb.png',
      post_text: '',
      post_title: '',
      post_tags: '',
      post_author: '',
      photo_value: '',
      title_value: '',
      text_value: '',
      tags_value: '',
      author_value: '',
      time: '',
      postsContent: []
    };
  },

  changeForm: function(data) {
    this.setState(data);
  },

  update: function() {
    var currentDate = new Date();
    var dateTime = currentDate.today();
    this.setState({
      postsContent: this.state.postsContent.concat({
        post_photo: this.state.post_photo,
        post_text: this.state.post_text,
        post_title: this.state.post_title,
        post_tags: this.state.post_tags.split(', '),
        post_author: this.state.post_author,
        time: dateTime
      }),
      photo_value: '',
      title_value: '',
      text_value: '',
      tags_value: '',
      author_value: '',
      
    });
    
   modal.style.display = "none";
  },

  render: function() {
    
    return (
      <section className='posts clearfix'>
        <AddPost
          changeForm={this.changeForm}
          update={this.update}
          photoValue={this.state.photo_value}
          titleValue={this.state.title_value}
          textValue={this.state.text_value}
          tagsValue={this.state.tags_value}
          authorValue={this.state.author_value}
          />{this.state.postsContent.map(function(content) {
          return <SinglePost postText={content.post_text} postTitle={content.post_title} postPhoto={content.post_photo} postTags={content.post_tags} postAuthor={content.post_author} time={content.time}/>
        })}         
      </section>
    )
  }
})

var AddPost = React.createClass({
  changePhoto: function(event) {
    this.props.changeForm({
      post_photo: event.target.value,
      photo_value: event.target.value
    })
  },

  changeTitle: function(event) {
    this.props.changeForm({
      post_title: event.target.value,
      title_value: event.target.value
    })
  },

  changeText: function(event) {
    this.props.changeForm({
      post_text: event.target.value,
      text_value: event.target.value
    })
  },
  
  changeTags: function(event) {
    this.props.changeForm({
      post_tags: event.target.value,
      tags_value: event.target.value
    })
  },
  
  changeAuthor: function(event) {
    this.props.changeForm({
      post_author: event.target.value,
      author_value: event.target.value
    })
  },

  render: function() {
    return (
      <div className='modal' id='myModal' >  		
        <div className='modal-content'>
          <span className="close-modal">x</span>
          <ul>
            <li><p>Photo:</p><input type="text" className='post-photo-input' placeholder="Post's photo (direct URL)" onChange={this.changePhoto} value={this.props.photoValue}/></li>
            <li><p>Title:</p><input type="text" ref='titleInput' className='post-title-input' placeholder='Enter the title of your post' onChange={this.changeTitle} value={this.props.titleValue}/></li>
    		    <li><p>Text:</p><textarea  ref="myArea" className='post-text-input' placeholder='Enter text of your post' rows='10' onChange={this.changeText} value={this.props.textValue}></textarea></li>
            <li><p>Tags:</p><input type="text" className='post-tags' placeholder="Enter tags (e.g. nature, travel, politic)" onChange={this.changeTags} value={this.props.tagsValue}/></li>
            <li><p>Author:</p><input type="text" className='post-author' placeholder="Enter your name" onChange={this.changeAuthor} value={this.props.authorValue}/></li>
          </ul>
          <button onClick={this.props.update} className='modal-add-post'>ADD POST</button>       
        </div>
    	</div>
    )
  }
});

var MainApp = React.createClass({
  render: function() {
    return (
      <div>
        <Home/>        
         <Posts/>
      </div>
    )
  }
})

ReactDOM.render(<MainApp />,
  document.getElementById('app')
);


var add_btn = document.getElementById('add-post');
var modal = document.getElementById('myModal');
var close = document.getElementsByClassName('close-modal')[0];

add_btn.onclick = function() {
    modal.style.display = "block";
};

close.onclick = function() {
    modal.style.display = "none";
}

window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

